package com.sun.facelets.impl;

import java.net.URL;

public interface ResourceResolver {
    public URL resolveUrl(String path);
}
